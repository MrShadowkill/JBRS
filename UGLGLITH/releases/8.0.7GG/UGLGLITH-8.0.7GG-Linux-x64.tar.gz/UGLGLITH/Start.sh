#!/bin/sh
set -eu
cd -- "$(dirname -- "$0")"
export JBRS_SAVE="${JBRS_SAVE:-$PWD/save.json}"
exec ./UGLGLITH "$@"
