# Windows package verification

Rust 1.90.0; x86_64-pc-windows-gnu; MinGW-w64; SDL2 2.30.11.
PE32+ x64, system DLL imports plus bundled SDL2.dll.

Current source: 188 workspace tests passed, plus the separate native/GLES2
GL render/UI allocation tests. All 52 scene prototypes have finite geometry
within a 90,000-vertex formation budget. Scene updates allocate no Rust heap
memory. Existing HUD/world/AI code has its own allocations.

The current Windows EXE rendered 150 frames of scene 6 (400 toilets) and
300 frames of scene 100 (admin console and pink stools), under Wine 10,
OpenGL 2.1 / Mesa llvmpipe and SDL dummy audio. Windows-target workspace
clippy passed. Earlier audit and Start.cmd tests also passed.
Native Windows hardware, physical sound devices and Ironlake are untested.

Default save: %LOCALAPPDATA%/UGLGLITH/save.json. Extract the whole ZIP.
F6 switches scenes; E interacts. SHA256SUMS covers package files.

Scene timing update: scene changes every 15 seconds or at the end of a glitch burst, whichever comes first. Each switch restarts the deadline; simultaneous triggers cause one transition. Timer and one-shot completion event tests passed.
