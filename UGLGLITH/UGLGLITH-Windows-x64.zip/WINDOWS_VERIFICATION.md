# Windows package verification

Built with Rust 1.90.0, x86_64-pc-windows-gnu, MinGW-w64 and SDL2 2.30.11.
PE32+ x86-64; imports Windows system DLLs plus the bundled SDL2.dll.
No additional MinGW runtime DLLs are required.

Passed: Windows-target workspace clippy, 11 save-system tests on the host,
Windows EXE map audit under Wine 10, and 120 smoke frames under Wine
with OpenGL 2.1 / Mesa llvmpipe and SDL dummy audio.
The run included ChaosManager entities, missing textures, fake RAM/log UI
and audio corruption. Native Windows hardware has not been tested here.

Default Windows save location: %LOCALAPPDATA%/UGLGLITH/save.json.
SHA256SUMS covers the portable package's files.
