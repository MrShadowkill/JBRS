@echo off
setlocal
pushd "%~dp0"
if not exist "UGLGLITH.exe" goto missing
if not exist "SDL2.dll" goto missing
"%~dp0UGLGLITH.exe" %*
set "GAME_RESULT=%ERRORLEVEL%"
popd
if not "%GAME_RESULT%"=="0" pause
exit /b %GAME_RESULT%
:missing
echo Extract the entire archive, including UGLGLITH.exe and SDL2.dll.
popd
pause
exit /b 1
