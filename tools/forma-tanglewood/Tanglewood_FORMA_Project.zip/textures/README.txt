Place user-provided PNG/JPEG/WebP images here. Expected PNG names are in ../texture-slots.json.
